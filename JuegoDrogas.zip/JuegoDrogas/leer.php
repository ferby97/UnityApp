<?php


$dbname = 'UnityDB';
//$dbname = 'unitybd';

$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);


//recibe los datos de unity, usamos el valor de estas variables
$apellido = $_REQUEST['apellido'];


//pregunto si el id de usuario ya esta en la tabla
$IDexistente = mysqli_query($conect, "SELECT * FROM usuariodrogas WHERE apellido='$apellido' ");


//se obtienen todos los datos del usuario idUser
while($row = mysqli_fetch_array($IDexistente))
{
    $usuarioID = $row['id'];
    $usuarioNombre = $row['nombre'];
    $usuarioApellido = $row['apellido'];
    $usuarioSexo = $row['sexo'];
    $usuarioEdad = $row['edad'];

    echo $usuarioEdad;


}
//localhost/JuegoDrogas/leer.php?apellido=adad


//http://tadeolabhack.com:8081/test/Datos/leer.php?ape=pso


?>

