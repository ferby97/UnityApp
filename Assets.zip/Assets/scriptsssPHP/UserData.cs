﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UserData : MonoBehaviour
{
     private string getUrlEscribir = "http://tadeolabhack.com:8081/test/Datos/JuegoDrogas/escribir.php?";
    // private string getUrlEscribir = "http://localhost/JuegoDrogas/escribir.php";
   // private string getUrlEscribir = "http://soymariaojeda.com/mamappdb/escribir.php.php";



    //public int id = 1;
    private string nombre = "";
    private string apellido = "";
    private string sexo ="";
    private int edad = 0;
    private string eres = "";

    public InputField campoNombre;
    public InputField campoApellido;
    public InputField campoSexo;
    public InputField campoEdad;
    public InputField campoEresConsumidor;

    //[SerializeField]
    public void SenData()
    {
        StartCoroutine(enviarDatosUsuario());
        

    }
    public IEnumerator enviarDatosUsuario()
    {
        nombre = campoNombre.text;
        apellido = campoApellido.text;
        sexo = campoSexo.text;
        eres = campoEresConsumidor.text;

        if (campoEdad.text !="")
        {
            edad = int.Parse(campoEdad.text);
        }
        else
        {
            print("el campo de edad no puede estar vacio ");
        }

        print( nombre + "" + apellido + "" + sexo +""+ edad + ""+eres);

        if (nombre ==""|| apellido == "" || sexo == "" || edad ==0 || eres=="")
        {
            print("los campos de nombre,apellido, edad, sexo y eres deben tener informacion");
        }
        else 
        {
            WWWForm form = new WWWForm();
            //form.AddField("id", id);
            form.AddField("nom", nombre);
            form.AddField("ape", apellido);
            form.AddField("se", sexo);
            form.AddField("ed", edad);
            form.AddField("er", eres);

            WWW retroalimentacion = new WWW(getUrlEscribir, form);
            yield return retroalimentacion;

            print(retroalimentacion.text);


        }





    }

}
