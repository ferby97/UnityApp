﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InfoUser3 : MonoBehaviour
{
    private string UrlPosition = "http://tadeolabhack.com:8081/test/Datos/JuegoDrogas/MostrarPosXusuarioTres.php";

   // private string UrlPosition = "http://localhost/JuegoDrogas/MostrarPosXusuarioTres.php";

   

    public Text TextoPuesto;
    public Text TextClick;

    public int idUser = 300;

    public void obtenerInfo()
    {
        StartCoroutine(datos());
    }

    public IEnumerator datos()
    {
        string info = UrlPosition + "?id=" + idUser;

        WWW resultInfo = new WWW(info);

        yield return resultInfo;

        print(resultInfo.text);

        TextoPuesto.text = resultInfo.text;

        


    }






}