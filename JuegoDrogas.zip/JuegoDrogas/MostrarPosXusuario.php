<?php


$dbname = 'UnityDB';
//$dbname = 'unitybd';

$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);

$userID = $_REQUEST['id'];

//consultar la tabla
$consulta = mysqli_query($conect, "SELECT * FROM usuariodrogas WHERE id ='$userID' ");


while($posicion= mysqli_fetch_array($consulta))
{
	echo$pos = $posicion['nombre'];
	echo "\n";
}


//localhost/JuegoDrogas/MostrarPosXusuario.php?id=320

//http://tadeolabhack.com:8081/test/Datos/MostrarPosXusuario.php?IDuser=85

?>