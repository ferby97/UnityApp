<?php



$dbname = 'UnityDB';
//$dbname = 'unitybd';

$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);


//recibe los datos de unity, usamos el valor de estas variables
$id = $_REQUEST['id'];
$nombre = $_REQUEST['nom'];
$apellido = $_REQUEST['ape'];
$sexo = $_REQUEST['se'];
$edad = $_REQUEST['ed'];
$eres = $_REQUEST['er'];


  //insertar Valores en la base de datos Bonotes
  $adicionarDatos = mysqli_query($conect, "INSERT INTO usuariodrogas(id,nombre,apellido,sexo,edad,eres) VALUES('$id','$nombre','$apellido','$sexo','$edad','$erer')");

  echo "adicionado";





//http://tadeolabhack.com:8081/test/Datos/escribir.php?identificacion=200&nom=pepito&ape=perez&ed=16

//http://localhost/JuegoDrogas/escribir.php?id=1&nom=Jorge&ape=pepito&se=hombre&ed=12&er=consumidor

?>

