﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Borrar : MonoBehaviour
{
     private string UrlBorrar = "http://tadeolabhack.com:8081/test/Datos/JuegoDrogas/BorrarDatos.php";
  //  private string UrlBorrar = "http://localhost/JuegoDrogas/BorrarDatos.php";

    public int id = 317;

    public void borrarTodo()
    {
        StartCoroutine(borrarT());
    }

    private IEnumerator borrarT()
    {
        WWWForm form = new WWWForm();

        form.AddField("in", "BorrarTodo");
        form.AddField("userID", 0);

        WWW retroalimentacion = new WWW(UrlBorrar, form);
        yield return retroalimentacion;

        print(retroalimentacion.text);

    }


    public void borrarUsuario()
    {
        StartCoroutine(borrarU());
    }

    private IEnumerator borrarU()
    {
        WWWForm form = new WWWForm();

        form.AddField("in", "BorrarUsuario");
        form.AddField("userID", id);

        WWW retroalimentacion = new WWW(UrlBorrar, form);
        yield return retroalimentacion;

        print(retroalimentacion.text);

    }

    public void borrarDatosUsuario()
    {
        StartCoroutine(borrarDU());
    }

    private IEnumerator borrarDU()
    {
        WWWForm form = new WWWForm();

        form.AddField("in", "BorrarDatosUsuario");
        form.AddField("userID", id);

        WWW retroalimentacion = new WWW(UrlBorrar, form);
        yield return retroalimentacion;

        print(retroalimentacion.text);
    }



}
