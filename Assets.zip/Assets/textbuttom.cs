﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class textbuttom : MonoBehaviour
{
    public GameObject Menu;
    public GameObject settingsPanel;

    private Animator menuAnim;
    private Animator settingsPanelAnim;

    private void Awake()
    {
        menuAnim = Menu.GetComponent<Animator>();
        settingsPanelAnim = settingsPanel.GetComponent<Animator>();
     
    }
    public void Settings()
    {
        settingsPanel.SetActive(true);
        //sacar menu principal
        menuAnim.SetBool("close", true);

        settingsPanelAnim.SetBool("open",true);
    }


   public void playScene()
    {
        SceneManager.LoadScene("Scan");
    }
}
