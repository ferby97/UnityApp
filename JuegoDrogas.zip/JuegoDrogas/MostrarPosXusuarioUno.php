<?php


$dbname = 'UnityDB';
//$dbname = 'unitybd';

$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);

$userID = $_REQUEST['id'];

//consultar la tabla
$consulta = mysqli_query($conect, "SELECT * FROM preguntadrograsuno WHERE id ='$userID' ");


while($posicion= mysqli_fetch_array($consulta))
{
	echo$pos = $posicion['btnpregunta1'];
	echo "\n";
}


//localhost/JuegoDrogas/MostrarPosXusuarioUno.php?id=6

//http://tadeolabhack.com:8081/test/Datos/MostrarPosXusuarioUno.php?IDuser=6

?>