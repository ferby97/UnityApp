﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class botones4 : MonoBehaviour
{
     private string urlBotoenes= "http://tadeolabhack.com:8081/test/Datos/JuegoDrogas/PostSelectCuatro.php?";
    //private string urlBotoenes = "http://localhost/JuegoDrogas/PostSelectCuatro.php";
    private int IDitem = 0;
    public int IDUser = 0;

    public void SelecItem (int temp)
    {
        IDitem = temp;
        StartCoroutine(sendItem());

    }

    private IEnumerator sendItem()
    {
        print(IDitem + " " + IDUser);

        WWWForm form = new WWWForm();

        form.AddField("userID", IDUser);
        form.AddField("itemID", IDitem);

        WWW retroalimentacion = new WWW(urlBotoenes, form);

        yield return retroalimentacion;

        print(retroalimentacion.text);

       // IDitem = 0;
       // IDUser = 0;
    }




}
