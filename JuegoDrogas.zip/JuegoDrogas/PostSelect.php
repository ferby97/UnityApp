<?php


$dbname = 'UnityDB';
//$dbname = 'unitybd';

$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);


//recibe los datos de unity, usamos el valor de estas variables
$userID = $_REQUEST['userID'];
$itemID = $_REQUEST['itemID'];



//pregunto si el id de usuario ya esta en la tabla
$IDexistente = mysqli_query($conect, "SELECT * FROM preguntadrograsuno WHERE idUsuario='$userID' ");


//se obtienen todos los datos del usuario idUser
while($row = mysqli_fetch_array($IDexistente))
{
	$id = $row['id'];

    $idSelectU = $row['idUsuario'];
    $boton1 = $row['btnpregunta1'];
	$boton2 = $row['btnpregunta2'];
	$boton3 = $row['btnpregunta3'];
	
}



//si no hay idSelect, significa que el usuario no existe
if($id == null && $idSelectU != $userID)
{
	
	if($itemID == 1)
	{
		//en el php le adiciono +1 al btn1
		$variablebtnpregunta1 = 1;
	}
	else
	{
		$variablebtnpregunta1 = 0;
	}

	if($itemID == 2)
	{
		//en el php le adiciono +1 al btn2
		$variablebtnpregunta2 = 1;
	}
	else
	{
		$variablebtnpregunta2 = 0;
	}

	if($itemID == 3)
	{
		//en el php le adiciono +1 al btn3
		$variablebtnpregunta3 = 1;
	}
	else
	{
		$variablebtnpregunta3 = 0;
	}

	

	//insertar Valores en la base de datos Bonotes
	$adicionarDatos = mysqli_query($conect, "INSERT INTO preguntadrograsuno(idUsuario,btnpregunta1,btnpregunta2,btnpregunta3) VALUES('$userID','$variablebtnpregunta1','$variablebtnpregunta2','$variablebtnpregunta3')");

	echo "adicionado";
}
//si el id de usuario si esta en la tabla entonces cambie los valores 
else
{
	if($itemID == 1)
	{
		//en el php le adiciono +1 al btn1
		$variablebtnpregunta1 = $boton1+1;

		$actualizabtnpregunta1 = mysqli_query($conect, "UPDATE preguntadrograsuno SET btnpregunta1=$variablebtnpregunta1  WHERE idUsuario='$userID' ");
	}	

	if($itemID == 2)
	{
		//en el php le adiciono +1 al btn2
		$variablebtnpregunta2 = $boton2+1;

		$actualizabtnpregunta2 = mysqli_query($conect, "UPDATE preguntadrograsuno SET btnpregunta2=$variablebtnpregunta2  WHERE idUsuario='$userID' ");

	}

	if($itemID == 3)
	{
		//en el php le adiciono +1 al btn3
		$variablebtnpregunta3 = $boton3+1;

		$actualizabtnpregunta3 = mysqli_query($conect, "UPDATE preguntadrograsuno SET btnpregunta3=$variablebtnpregunta3  WHERE idUsuario='$userID' ");
	}

	


	echo "Funciono!!!!!";

}







//http://tadeolabhack.com:8081/test/Datos/PostSelect.php?userID=0&itemID=2


//http://localhost/JuegoDrogas/PostSelect.php?userID=0&itemID=2

?>