<?php


$dbname = 'UnityDB';
//$dbname = 'unitybd';

$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);


//recibe los datos de unity, usamos el valor de estas variables

$nombre = $_REQUEST['nom'];
$apellido = $_REQUEST['ape'];
$sexo = $_REQUEST['se'];
$edad = $_REQUEST['ed'];
$eres = $_REQUEST['er'];


  //insertar Valores en la base de datos Bonotes
  $adicionarDatos = mysqli_query($conect, "INSERT INTO usuariodrogas(nombre,apellido,sexo,edad,eres) VALUES('$nombre','$apellido','$sexo','$edad','$eres')");

  echo "adicionado123";



//http://soymariaojeda.com/mamappdb/escribir.php.php

//http://tadeolabhack.com:8081/test/Datos/JuegoDrogas/escribir.php?id=99&nom=JUN&ape=SUA&se=MACHO&ed=20&er=consumidor

//http://localhost/JuegoDrogas/escribir.php?id=99&nom=GAB&ape=OJEDA&se=MUJER&ed=20&er=consumidor

?>

